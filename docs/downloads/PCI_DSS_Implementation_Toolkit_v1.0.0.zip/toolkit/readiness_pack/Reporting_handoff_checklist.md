# Reporting handoff — practical review checklist

**Independent worksheet, not an official AOC, SAQ or ROC.** Use Chapter 4 and the current official form accepted by your acquirer/payment brand. Retain the underlying assessment and sensitive evidence in your approved restricted repository; do not attach real payment data or credentials here.

## Prepare before requesting signatures

| Review decision | Responsible role (example) | Evidence to bring | Review result |
| --- | --- | --- | --- |
| Which role, services or channels are assessed? | Compliance owner + payment architect | Accepted reporting route, current diagrams, scope and exclusions | Open |
| Is the SAQ route permitted, and are all criteria met? | Compliance owner | Eligibility decision, provider-service evidence, data-path analysis; for an embedded SAQ A form, script-protection basis | Open |
| Does the provider AOC cover our exact service? | Supplier owner | Service name, included/excluded services, relevant locations, per-service findings, responsibility matrix | Open |
| Are results traceable to the underlying SAQ or ROC? | Assessment coordinator | Findings and evidence references; explain N/A and any untested items; do not convert internal NOT RUN to a formal outcome | Open |
| Are assessment dates and signatories consistent? | Assessment coordinator | SAQ completion date or ROC Date of Report; distinguish assessment end and actual signature dates | Open |
| Are unresolved issues visible? | Compliance owner | Exceptions, remediation, recipient instructions, evidence gaps | Open |
| Is the final package authorized for submission? | Authorized executive and relevant assessor(s) | Accepted current official forms and underlying report; review of claims and signatures | Open |

## Read the official summary, not only the overall status

For SAQ A r1, Part 2h records eligibility and Part 2g summarizes the related SAQ. In the ROC AOCs, Part 3 identifies full versus partial assessment. A positive partial result excludes requirements that were not tested. Do not interpret it as assurance for those requirements. The service-provider ROC AOC also has separate Part 2g summaries by service, with reasons for N/A and Not Tested. The SAQ A r1 summary refers to requirement families 2, 3, 6, 8, 9, 11 and 12. The ROC merchant summary covers 1–12 and A2; the ROC service-provider summary covers 1–12, A1 and A2. The row set is not an applicability decision, and DESV has separate reporting instruments when required. Confirm whether the recipient accepts the approach. When an official form calls for further review of a legal exception, follow that process. Do not complete the non-compliance action plan unless the recipient requests it for a non-compliant assessment.

AOC completion and signature roles depend on the actual assessment; the examples and AI editorial review in this publication are not a QSA/ISA assessment. Never reuse a fictional name or signature in an official attestation.

## Sources checked for this supplement

The source register in the original RC13 workbook/export is a frozen operational baseline. The following addendum corresponds to the expanded book references. Source review date: November 25, 2026. Obtain the accepted current forms from https://www.pcisecuritystandards.org/document_library/; the originals are not included here.

| Source | Version / date | Locator (PDF page number, not printed footer) |
| --- | --- | --- |
| S38 – SAQ Instructions and Guidelines | v4.0.1 r1, April 2025 | pp. 6, 13–15, 19–20, 27 |
| S39 – AOC for SAQ A | v4.0.1 r1, January 2025 | pp. 6–10 |
| S68 – ROC AOC Merchants | v4.0.1, August 2024 | pp. 4, 7–11 |
| S69 – ROC AOC Service Providers | v4.0.1, August 2024 | pp. 4–5, 9–13 |
| S70 – FAQ 1582 | August 2024 | https://www.pcisecuritystandards.org/faqs/1582/ |
| S71 – FAQ 1583 | August 2024 | https://www.pcisecuritystandards.org/faqs/1583/ |

FAQ 1588 clarifies the embedded-payment-form script eligibility condition. FAQ 1604 addresses merchant-page scanning. FAQ 1331 addresses the approved use of SAQ criteria in merchant ROC assessments. Read these in context; the checkboxes alone do not settle the validation route.
