# PCI DSS Implementation Toolkit | v1.0.0 (RC19 baseline)

**Independent educational companion.** The two RC13-named workbooks remain the synchronized operational core. RC19 retains the task and test-execution registers, source-page locators and reporting checklist. The RC13-named operational workbooks and matching CSVs remain unchanged. Each of the 508 active defined tests now has an individual evidence-preparation prompt. The TechSphere example is fictional; no production controls or evidence have been verified. This package is not an assessment or certification.

## Start here: from architecture to evidence

1. Extract the entire ZIP without changing its folder structure. Open `toolkit/PCI_DSS_Implementation_Workbook_BLANK_RC13.xlsx` for your project, or `toolkit/TechSphere_Implementation_Workbook_RC13.xlsx` to study the example. The corresponding exports are in `toolkit/registers/`.
2. Establish role, architecture, data flows and scope. Record the reporting method separately from control applicability. Reconcile the asset inventory, suppliers, scope and applicability notes. A SAQ membership flag is not an assessment decision.
3. Open `toolkit/readiness_pack/Explicit_work_tasks.csv`. Filter by requirement, direct package or work area. All 277 active identifiers have a task draft and example acceptance check. Assign actual owners and populations, resolve applicability, link the calendar where relevant, and define the evidence and review criteria. Consolidate tasks under existing packages instead of creating duplicate implementation work.
4. Open `toolkit/readiness_pack/Defined_test_execution_log.csv`. Follow the Task ID to the official testing identifier. Retrieve the current official standard, read the complete requirement, notes and tests, and record the actual method, sample, evidence and result. The individual preparation prompts identify evidence to bring for that specific test. Read the source before selecting a sample or method; prompts are not exhaustive instructions or official tests. The 508 active test rows are deliberately NOT RUN; the four historical rows are not current obligations. Repeat rows for multiple populations if needed; customized and compensating-control evidence requires separate treatment under the official instructions.
5. Use `toolkit/documents/` for the blank and fictional example documents. Exercise all applicable incident plan elements; see the Incident plan view and IR-01–07. Use labs only in an authorized development environment with synthetic data. Run `python -m unittest discover -v` from each lab folder; follow the individual dependency instructions. Browser exercises use Playwright and Chromium.
6. Read the current PCI SSC standard and forms at https://www.pcisecuritystandards.org/document_library/. The reference and calendar registers contain 280 identifiers (277 active, three historical), 512 defined testing identifiers and 198 calendar rows for 187 distinct requirements. The timing review and source-specific preparation prompts support planning; determine the full applicable test scope, method and evidence in your actual environment. Never invent a PCI DSS deadline from a planning trigger.

## Working files and evidence

The operational workbook and CSV exports are a single baseline; if you modify either, reconcile related identifiers. The new task and test files are separate working registers. Their join key is Task ID; the original requirement, package, and calendar references are preserved. Keep evidence in approved systems and use reference identifiers rather than live PAN, SAD, credentials or sensitive logs in shared files. No signed third-party AOC or third-party standard is included. The evidence index hashes identify distributed artifacts, not proof of compliance.

Reader downloads, errata and edition compatibility: https://bartekwiecek.github.io/mastering_PCI_DSS_Toolkit/.

For reporting preparation, use `toolkit/readiness_pack/Reporting_handoff_checklist.md` and the current official forms. Its references supplement the frozen operational source register.

## Verification history

The local regression logs and metrics are historical RC19 snapshots. Exact RC19 later passed 56 local and six browser cases (GitHub Actions run 45606388819), and anonymous delivery smoke tests passed (run 45607725041). The v1.0.0 release changes only publication wording and the artifact index; use its accompanying delivery-test-report.json for exact-archive CI evidence. These checks do not assess real-world PCI DSS compliance.
