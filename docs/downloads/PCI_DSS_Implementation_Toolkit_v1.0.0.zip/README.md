# PCI DSS Implementation Toolkit v1.0.0

Stable educational reader release, based on RC19. Extract the entire archive, then start with `toolkit/README.md`. No official PCI SSC or ISO standards are included. Educational use only; not an assessment or certification.

Compatible with Mastering PCI DSS 4.0.1 Compliance (the revised second or third edition, as applicable). The book's publication status is separate. See the release notes and errata at https://bartekwiecek.github.io/mastering_PCI_DSS_Toolkit/. Purchasers may adapt original implementation templates and example records for their own internal business use; no general redistribution or resale license is granted.
