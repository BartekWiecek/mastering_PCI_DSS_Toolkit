# PCI DSS Implementation Toolkit RC8

Candidate reader materials. Extract the entire archive, then start with `toolkit/README.md`. No official PCI SSC or ISO standards are included. Educational use only; not an assessment or certification.
