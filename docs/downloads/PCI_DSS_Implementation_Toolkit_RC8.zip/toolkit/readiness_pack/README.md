# Evidence index — RC8

Every file in the index is resolved relative to the extracted reader ZIP root (the directory containing `toolkit` and `labs`). SHA-256 identifies the exact distributed artifact. Synthetic regression logs record execution in the test environment. Browser execution, if blocked or failed, is explicitly identified and never represents a passed browser assertion. No historical result is substituted for this run. The separate evidence register contains expected production artifacts, not verified files. Local test logs do not establish PCI DSS compliance.
