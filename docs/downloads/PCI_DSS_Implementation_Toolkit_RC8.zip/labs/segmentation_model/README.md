# Lab 6: segmentation policy model

Run `python -m unittest -v test_model.py` here in Python 3.11+. Standard library only. `model.py` reads the current bundled register `toolkit/registers/14_network_policy_example.csv` (reader archive); no source-tree fixture is needed. The graph is a separate model of selected management capabilities; a route denial is not proof of privilege isolation. Tests TS-NET-09 and TS-NET-10 intentionally detect bad model changes, then verify the restored model. A passing test means the bad condition was detected, not accepted.

No packet capture, live firewall, cloud API, scanner, network connection or production credentials are involved. Does not model the whole CDE, public ingress, stateful return traffic, route precedence, DNS resolution, IPv6 or all indirect paths. Use actual qualified independent testing for Requirement 11.4.5 where applicable. Results are not TS-EV-19/20 production evidence.
