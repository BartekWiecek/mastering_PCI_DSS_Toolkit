import unittest
from model import load_rules, allowed, control_path, CONTROL

class PolicyTests(unittest.TestCase):
    def setUp(self): self.rules = load_rules()
    def test_TS_NET_01_ingress(self):
        self.assertTrue(allowed(self.rules,"TS-EDGE-01","TS-PAY-01","tcp",443))
    def test_TS_NET_02_provider(self):
        self.assertTrue(allowed(self.rules,"TS-PAY-01","TS-TPSP-01","tcp",443))
    def test_TS_NET_03_unknown_destination(self):
        self.assertFalse(allowed(self.rules,"TS-PAY-01","UNAPPROVED","tcp",443))
    def test_TS_NET_04_reporting_denied(self):
        self.assertFalse(allowed(self.rules,"TS-CAT-01","TS-PAY-01","tcp",443))
    def test_TS_NET_05_worker_denied(self):
        self.assertFalse(allowed(self.rules,"TS-WORK-01","TS-PAY-01","tcp",443))
    def test_TS_NET_06_dns(self):
        for protocol in ("udp","tcp"):
            self.assertTrue(allowed(self.rules,"TS-PAY-01","TS-RESOLVE-01",protocol,53))
    def test_TS_NET_07_port_denied(self):
        self.assertFalse(allowed(self.rules,"TS-EDGE-01","TS-PAY-01","tcp",8080))
    def test_TS_NET_08_bad_inputs(self):
        self.assertFalse(allowed(self.rules,"","TS-PAY-01","tcp",443))
        self.assertFalse(allowed(self.rules,"TS-EDGE-01","TS-PAY-01","udp",443))
        self.assertFalse(allowed(self.rules,"TS-EDGE-01","TS-PAY-01","tcp",True))
    def test_TS_NET_09_policy_fault(self):
        broken = self.rules | {("TS-CAT-01","TS-PAY-01","tcp",443)}
        self.assertTrue(allowed(broken,"TS-CAT-01","TS-PAY-01","tcp",443))
        self.assertFalse(allowed(self.rules,"TS-CAT-01","TS-PAY-01","tcp",443))
    def test_TS_NET_10_indirect_control_fault(self):
        broken = CONTROL | {("TS-CAT-01","TS-CI-01")}
        self.assertEqual(control_path(broken,"TS-CAT-01","TS-PAY-01"),
                         ("TS-CAT-01","TS-CI-01","TS-PAY-01"))
        self.assertIsNone(control_path(CONTROL,"TS-CAT-01","TS-PAY-01"))
    def test_TS_NET_11_expected_admin_influence(self):
        self.assertIsNotNone(control_path(CONTROL,"TS-ID-01","TS-PAY-01"))
    def test_TS_NET_12_cycle_terminates(self):
        edges = CONTROL | {("TS-CI-01","TS-ID-01")}
        self.assertIsNone(control_path(edges,"TS-ID-01","TS-CAT-01"))

if __name__ == "__main__": unittest.main(verbosity=2)
