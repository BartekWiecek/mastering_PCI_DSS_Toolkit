"""Offline policy teaching model; never configures a network."""
import csv
from pathlib import Path
from collections import deque

PACKAGE_ROOT = Path(__file__).resolve().parents[2]
# Use only the current register bundled with the selected installation.
# The author project uses toolkit_edition; the reader archive uses toolkit.
REGISTER_ROOT = PACKAGE_ROOT / ("toolkit" if (PACKAGE_ROOT / "toolkit").is_dir() else "toolkit_edition") / "registers"
RULES_PATH = REGISTER_ROOT / "14_network_policy_example.csv"

def load_rules(path=RULES_PATH):
    with open(path, encoding="utf-8-sig", newline="") as file:
        return frozenset((r["Source"], r["Destination"], r["Protocol"], int(r["Port"]))
                         for r in csv.DictReader(file))

def allowed(rules, source, destination, protocol, port):
    if not source or not destination or protocol not in {"tcp", "udp"}:
        return False
    if type(port) is not int or not 1 <= port <= 65535:
        return False
    return (source, destination, protocol, port) in rules

# Directed edges mean "can affect or grant control over", NOT packet paths.
# This deliberately small graph is a hypothesis, not a complete IAM export.
CONTROL = frozenset({("TS-ID-01", "TS-CI-01"),
                     ("TS-ID-01", "TS-ADMIN-01"),
                     ("TS-CI-01", "TS-PAY-01"),
                     ("TS-ADMIN-01", "TS-PAY-01"),
                     ("TS-KEY-01", "TS-PAY-01")})

def control_path(edges, source, target):
    pending = deque([(source,)])
    seen = {source}
    while pending:
        path = pending.popleft()
        if path[-1] == target:
            return path
        for start, end in sorted(edges):
            if start == path[-1] and end not in seen:
                seen.add(end)
                pending.append(path + (end,))
    return None
