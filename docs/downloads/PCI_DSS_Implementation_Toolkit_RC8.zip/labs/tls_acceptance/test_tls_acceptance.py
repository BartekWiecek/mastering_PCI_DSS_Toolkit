"""Offline TLS handshake lab. Synthetic, short-lived key material only.

Run: python -m unittest -v test_tls_acceptance.py
Requires Python 3.11+ with TLS 1.3 support and openssl CLI.
No network sockets or third-party payment services are used.
"""
import ssl
import subprocess
import tempfile
import unittest
import warnings
from pathlib import Path

HOST = 'checkout.example.test'


def handshake(client, server, hostname=HOST):
    """Exchange TLS handshake messages through MemoryBIO, not a socket."""
    ci, co, si, so = [ssl.MemoryBIO() for _ in range(4)]
    c = client.wrap_bio(ci, co, server_hostname=hostname)
    s = server.wrap_bio(si, so, server_side=True)
    c_done = s_done = False
    for _ in range(64):
        if not c_done:
            try:
                c.do_handshake()
                c_done = True
            except ssl.SSLWantReadError:
                pass
        if co.pending:
            si.write(co.read())
        if not s_done:
            try:
                s.do_handshake()
                s_done = True
            except ssl.SSLWantReadError:
                pass
        if so.pending:
            ci.write(so.read())
        if c_done and s_done:
            return c.version(), c.cipher()[0]
    raise RuntimeError('Handshake did not complete within bounded iterations')


class TestTLSAcceptance(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix='synthetic_tls_')
        cls.addClassCleanup(cls.temp.cleanup)
        root = Path(cls.temp.name)
        cls.cert = root / 'cert.pem'
        cls.key = root / 'key.pem'
        subprocess.run(['openssl', 'req', '-x509', '-newkey', 'rsa:2048',
                        '-nodes', '-days', '1', '-subj', f'/CN={HOST}',
                        '-addext', f'subjectAltName=DNS:{HOST}',
                        '-keyout', str(cls.key), '-out', str(cls.cert)],
                       check=True, capture_output=True)

    def server(self):
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.maximum_version = ssl.TLSVersion.TLSv1_3
        ctx.set_ciphers('ECDHE+AESGCM')  # TLS 1.2; TLS 1.3 configured separately by runtime
        ctx.load_cert_chain(str(self.cert), str(self.key))
        return ctx

    def client(self, trust=True):
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.maximum_version = ssl.TLSVersion.TLSv1_3
        ctx.set_ciphers('ECDHE+AESGCM')
        if trust:
            ctx.load_verify_locations(cafile=str(self.cert))
        return ctx

    def test_trusted_tls12(self):
        c = self.client()
        c.maximum_version = ssl.TLSVersion.TLSv1_2
        version, cipher = handshake(c, self.server())
        self.assertEqual(version, 'TLSv1.2')
        self.assertIn('GCM', cipher)

    def test_trusted_tls13(self):
        c = self.client()
        c.minimum_version = ssl.TLSVersion.TLSv1_3
        version, cipher = handshake(c, self.server())
        self.assertEqual(version, 'TLSv1.3')
        self.assertTrue(cipher.startswith('TLS_'))

    def test_untrusted_certificate(self):
        with self.assertRaises(ssl.SSLCertVerificationError):
            handshake(self.client(trust=False), self.server())

    def test_hostname_mismatch(self):
        with self.assertRaises(ssl.SSLCertVerificationError):
            handshake(self.client(), self.server(), 'wrong.example.test')

    def test_no_legacy_protocol_negotiated(self):
        c = self.client()
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', DeprecationWarning)
            c.minimum_version = c.maximum_version = ssl.TLSVersion.TLSv1_1
        s = self.server()
        self.assertEqual(s.minimum_version, ssl.TLSVersion.TLSv1_2)
        # The runtime may reject the old client before the server sees a message.
        # This is a local rejection check, not proof of a production server policy.
        with self.assertRaises(ssl.SSLError):
            handshake(c, s)

    def test_disjoint_supported_versions(self):
        c = self.client()
        c.maximum_version = ssl.TLSVersion.TLSv1_2
        s = self.server()
        s.minimum_version = ssl.TLSVersion.TLSv1_3
        with self.assertRaises(ssl.SSLError):
            handshake(c, s)


if __name__ == '__main__':
    unittest.main(verbosity=2)
