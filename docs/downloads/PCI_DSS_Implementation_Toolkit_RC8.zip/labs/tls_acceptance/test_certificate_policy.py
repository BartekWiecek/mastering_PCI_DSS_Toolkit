"""Synthetic PKI and TLS acceptance checks. No sockets, real keys or account data."""
from datetime import datetime, timedelta, timezone
from pathlib import Path
import ssl
import tempfile
import unittest
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID
from test_tls_acceptance import HOST, handshake


class TestCertificatePolicy(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        temp = tempfile.TemporaryDirectory(prefix='synthetic_pki_')
        cls.addClassCleanup(temp.cleanup)
        cls.root = Path(temp.name)
        now = datetime.now(timezone.utc)
        day = timedelta(days=1)
        root_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        root_name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'Lab-only root CA')])
        root_cert = (x509.CertificateBuilder().subject_name(root_name).issuer_name(root_name)
                     .public_key(root_key.public_key()).serial_number(x509.random_serial_number())
                     .not_valid_before(now - 10*day).not_valid_after(now + 10*day)
                     .add_extension(x509.BasicConstraints(ca=True, path_length=0), True)
                     .add_extension(x509.KeyUsage(digital_signature=False, content_commitment=False,
                         key_encipherment=False, data_encipherment=False, key_agreement=False,
                         key_cert_sign=True, crl_sign=True, encipher_only=False, decipher_only=False), True)
                     .add_extension(x509.SubjectKeyIdentifier.from_public_key(root_key.public_key()), False)
                     .sign(root_key, hashes.SHA256()))
        leaf_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        cls.key = cls.root/'leaf.key'
        cls.key.write_bytes(leaf_key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
        cls.key.chmod(0o600)
        certs = {}
        for label, start, end in [('valid', now-day, now+day), ('expired', now-3*day, now-day), ('future', now+day, now+3*day), ('revoked', now-day, now+day)]:
            cert = (x509.CertificateBuilder().subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, HOST)]))
                    .issuer_name(root_name).public_key(leaf_key.public_key()).serial_number(x509.random_serial_number())
                    .not_valid_before(start).not_valid_after(end)
                    .add_extension(x509.BasicConstraints(ca=False,path_length=None),True)
                    .add_extension(x509.SubjectAlternativeName([x509.DNSName(HOST)]),False)
                    .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]),False)
                    .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(root_key.public_key()),False)
                    .sign(root_key,hashes.SHA256()))
            (cls.root/(label+'.pem')).write_bytes(cert.public_bytes(serialization.Encoding.PEM)); certs[label]=cert
        revoked = x509.RevokedCertificateBuilder().serial_number(certs['revoked'].serial_number).revocation_date(now-timedelta(hours=1)).build()
        crl = (x509.CertificateRevocationListBuilder().issuer_name(root_name).last_update(now-day).next_update(now+day)
               .add_revoked_certificate(revoked).sign(root_key,hashes.SHA256()))
        cls.trust = cls.root/'trust.pem'
        cls.trust.write_bytes(root_cert.public_bytes(serialization.Encoding.PEM)+crl.public_bytes(serialization.Encoding.PEM))

    def endpoints(self, leaf='valid', client_cipher='ECDHE-RSA-AES128-GCM-SHA256', server_cipher='ECDHE-RSA-AES128-GCM-SHA256'):
        client = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        client.load_verify_locations(cafile=str(self.trust))
        client.verify_flags |= ssl.VERIFY_CRL_CHECK_LEAF
        server = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        for ctx, cipher in [(client,client_cipher),(server,server_cipher)]:
            ctx.minimum_version = ctx.maximum_version = ssl.TLSVersion.TLSv1_2
            ctx.set_ciphers(cipher)
        server.load_cert_chain(str(self.root/(leaf+'.pem')), str(self.key))
        return client, server

    def test_valid_nonrevoked_certificate(self):
        self.assertEqual(handshake(*self.endpoints()), ('TLSv1.2','ECDHE-RSA-AES128-GCM-SHA256'))

    def rejected(self, label, code):
        with self.assertRaises(ssl.SSLCertVerificationError) as error:
            handshake(*self.endpoints(label))
        self.assertEqual(error.exception.verify_code, code)

    def test_expired_leaf(self): self.rejected('expired', 10)
    def test_not_yet_valid_leaf(self): self.rejected('future', 9)
    def test_revoked_leaf(self): self.rejected('revoked', 23)

    def test_no_shared_tls12_cipher(self):
        with self.assertRaises(ssl.SSLError) as error:
            handshake(*self.endpoints(server_cipher='ECDHE-RSA-AES256-GCM-SHA384'))
        self.assertIn('NO_SHARED_CIPHER', str(error.exception))


if __name__ == '__main__': unittest.main(verbosity=2)
