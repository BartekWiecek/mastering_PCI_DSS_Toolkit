# Offline TLS acceptance exercise

Chapter 7. Run `python -m unittest discover -v` in this directory. Requires Python 3.11+ with TLS 1.3 support and OpenSSL CLI. Generates a disposable self-signed certificate in a temporary directory and uses in-memory SSL BIOs. The generated key/certificate are never included in the book or toolkit.

Six tests exercise successful TLS 1.2 and 1.3 negotiation, untrusted peer rejection, hostname mismatch, failure to negotiate TLS 1.1, and a separate no-common-version case. The old client may fail within the local runtime before the server receives a handshake; this does not prove that a remote endpoint rejects old TLS. `set_ciphers` controls TLS 1.2 suites in Python's API, not TLS 1.3 suites. The original six-test fixture relies on the runtime's TLS 1.3 defaults. Those six tests alone do not test every cipher, certificate expiry or revocation, production network, real payment integration, or complete PCI DSS compliance. The synthetic self-signed trust setup is not a recommended production PKI. Test the actual environment separately with authorized tools.

Results in the current Toolkit evidence index and regression log are real results for the synthetic fixture only. Do not treat them as TS-EV-09 production evidence. No real payment data is used.

## Certificate-policy fixture

Run `python -m unittest discover -v` from this directory (also requires the `cryptography` Python package). Five additional tests generate a temporary root CA and leaf certificates and exercise a local, signed CRL, expired and future-dated leaf rejection, revoked leaf rejection and mismatched TLS 1.2 cipher suites. Keys are transient. Revocation testing is limited to local leaf CRL validation; it neither fetches live CRLs/OCSP nor validates a deployed service. Cipher tests restrict TLS 1.2 only. Do not upload lab keys or pass these results off as TS-EV-09 production evidence. Actual execution results are recorded under the toolkit's `local_regression` folder.
