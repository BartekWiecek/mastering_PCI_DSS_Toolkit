import unittest
from model import Order, signature, demo_event

class PaymentTests(unittest.TestCase):
    def setUp(self): self.order = Order()
    def accept(self, raw): return self.order.accept(raw, signature(raw))
    def test_TS_PMT_01_valid_event(self):
        self.assertEqual(self.accept(demo_event()),"accepted")
        self.assertEqual((self.order.state,self.order.fulfillment_count),("paid",1))
    def test_TS_PMT_02_signature(self):
        raw = demo_event()
        self.assertEqual(self.order.accept(raw,"0"*64),"reject-signature")
        self.assertEqual(self.order.accept(raw,"ł"*64),"reject-signature")
        self.assertEqual(self.order.fulfillment_count,0)
    def test_TS_PMT_03_binding(self):
        for k,v in [("amount_minor",1),("currency","EUR"),("merchant","OTHER"),("reference","OTHER"),("order_id","OTHER")]:
            with self.subTest(k=k): self.assertEqual(self.accept(demo_event(**{k:v})),"reject-binding")
        self.assertEqual(self.order.fulfillment_count,0)
    def test_TS_PMT_04_duplicate(self):
        raw = demo_event()
        self.assertEqual(self.accept(raw),"accepted")
        self.assertEqual(self.accept(raw),"duplicate")
        self.assertEqual(self.order.fulfillment_count,1)
    def test_TS_PMT_05_old_event(self):
        self.assertEqual(self.accept(demo_event(version=3)),"accepted")
        self.assertEqual(self.accept(demo_event(event_id="OLDER",version=2,state="pending")),"stale")
        self.assertEqual((self.order.state,self.order.version),("paid",3))
    def test_TS_PMT_06_downgrade(self):
        self.accept(demo_event())
        self.assertEqual(self.accept(demo_event(event_id="NEW",version=2,state="failed")),"reject-transition")
        self.assertEqual(self.order.state,"paid")
    def test_TS_PMT_07_malformed(self):
        for raw in (b"{", b'{"state":"paid","state":"failed"}', b"[]", demo_event(version=True),demo_event(extra="x")):
            self.assertEqual(self.accept(raw),"reject-schema")
        self.assertEqual(self.order.fulfillment_count,0)
    def test_TS_PMT_08_browser_return(self):
        self.assertEqual(self.order.browser_return(),"display-status-only")
        self.assertEqual((self.order.state,self.order.fulfillment_count),("pending",0))
    def test_TS_PMT_09_conflicting_duplicate(self):
        self.accept(demo_event())
        self.assertEqual(self.accept(demo_event(version=2)),"reject-event-conflict")
    def test_TS_PMT_10_conflicting_version(self):
        self.accept(demo_event())
        self.assertEqual(self.accept(demo_event(event_id="NEW")),"reject-version-conflict")
    def test_TS_PMT_11_repeat_paid(self):
        self.accept(demo_event())
        self.assertEqual(self.accept(demo_event(event_id="NEW",version=2)),"accepted")
        self.assertEqual(self.order.fulfillment_count,1)
    def test_TS_PMT_12_retry_new_attempt_required(self):
        self.accept(demo_event(state="failed"))
        self.assertEqual(self.accept(demo_event(event_id="NEW",version=2)),"reject-transition")
        self.assertEqual(self.order.fulfillment_count,0)

if __name__ == "__main__": unittest.main(verbosity=2)
