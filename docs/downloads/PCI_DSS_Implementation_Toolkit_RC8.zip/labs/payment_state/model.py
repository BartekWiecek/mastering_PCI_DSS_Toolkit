"""Synthetic single-process state machine; not a payment-provider SDK."""
from dataclasses import dataclass, field
import hashlib, hmac, json

DEMO_KEY = b"public-fixture-key-not-a-production-secret"
FIELDS = {"event_id", "order_id", "merchant", "reference", "amount_minor", "currency", "version", "state"}

def signature(raw):
    return hmac.new(DEMO_KEY, raw, hashlib.sha256).hexdigest()

def unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result: raise ValueError("duplicate JSON key")
        result[key] = value
    return result

@dataclass
class Order:
    order_id: str = "TS-ORDER-DEMO-01"
    merchant: str = "TS-MERCHANT-DEMO"
    reference: str = "TS-PAYMENT-DEMO"
    amount_minor: int = 12500
    currency: str = "USD"
    version: int = 0
    state: str = "pending"
    processed: dict = field(default_factory=dict)
    fulfillment_count: int = 0

    def browser_return(self):
        return "display-status-only"

    def accept(self, raw, supplied_signature):
        if not isinstance(raw, bytes) or len(raw) > 8192:
            return "reject-envelope"
        if not isinstance(supplied_signature, str) or len(supplied_signature) != 64:
            return "reject-signature"
        if not supplied_signature.isascii():
            return "reject-signature"
        if not hmac.compare_digest(signature(raw), supplied_signature):
            return "reject-signature"
        try:
            event = json.loads(raw, object_pairs_hook=unique_pairs)
        except (UnicodeError, ValueError, RecursionError):
            return "reject-schema"
        if not isinstance(event, dict) or set(event) != FIELDS:
            return "reject-schema"
        if any(not isinstance(event[k], str) or not event[k] for k in FIELDS-{"version","amount_minor"}):
            return "reject-schema"
        if type(event["version"]) is not int or event["version"] < 1 or type(event["amount_minor"]) is not int:
            return "reject-schema"
        if event["state"] not in {"pending", "paid", "failed"}:
            return "reject-schema"
        if any(event[k] != getattr(self,k) for k in ("order_id","merchant","reference","amount_minor","currency")):
            return "reject-binding"
        digest = hashlib.sha256(raw).hexdigest()
        if event["event_id"] in self.processed:
            return "duplicate" if self.processed[event["event_id"]] == digest else "reject-event-conflict"
        if event["version"] < self.version:
            return "stale"
        if event["version"] == self.version:
            return "reject-version-conflict"
        if self.state == "paid" and event["state"] != "paid":
            return "reject-transition"
        if self.state == "failed" and event["state"] != "failed":
            return "reject-transition"
        if self.state == "pending" and event["state"] == "paid":
            self.fulfillment_count += 1
        self.version = event["version"]
        self.state = event["state"]
        self.processed[event["event_id"]] = digest
        return "accepted"

def demo_event(**changes):
    event = dict(event_id="EV-DEMO-01",order_id="TS-ORDER-DEMO-01",
                 merchant="TS-MERCHANT-DEMO", reference="TS-PAYMENT-DEMO",
                 amount_minor=12500,currency="USD",version=1,state="paid")
    event.update(changes)
    return json.dumps(event,sort_keys=True,separators=(",", ":")).encode()
