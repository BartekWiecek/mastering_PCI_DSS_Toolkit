# Lab 9 — browser-side integrity (synthetic, local only)

Requires Python 3, Playwright and Chromium (`python -m pip install playwright`, then `python -m playwright install chromium`). Run `python browser_lab.py` on an authorized workstation. No real account data or external endpoints. The server binds only to loopback; retain the normal browser sandbox.

Six browser cases: approved resource, modified resource, missing CSP, changed HTML, restored baseline, and report-only policy. The report-only case observes script execution and a browser policy-violation event; it is distinct from enforcement. This fixture compares selected received content and headers and does not represent the full 11.6.1 mechanism.

Run `python -m unittest discover -v` for the separate local tests. Consult the current evidence index and browser log in the Toolkit. The browser test is independent of the local HTTP tests. Do not disable or circumvent administrative policy. Neither test suite constitutes production assessment evidence.
