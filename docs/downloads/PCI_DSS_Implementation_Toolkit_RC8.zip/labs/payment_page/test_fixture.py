import hashlib, base64, unittest, threading, urllib.request
from http.server import ThreadingHTTPServer
from browser_lab import APPROVED, CHANGED, DIGEST, POLICY, html_body
import browser_lab as lab

def digest(data): return 'sha384-'+base64.b64encode(hashlib.sha384(data).digest()).decode('ascii')

class TestFixture(unittest.TestCase):
    def tearDown(self): lab.MODE='approved'
    def test_integrity_matches_approved(self): self.assertEqual(digest(APPROVED), DIGEST)
    def test_changed_resource_does_not_match(self): self.assertNotEqual(digest(CHANGED), DIGEST)
    def test_html_uses_pinned_digest(self): self.assertIn(DIGEST.encode(),html_body())
    def test_html_tamper_changes_snapshot(self):
        lab.MODE='approved'; original=hashlib.sha256(html_body()).digest()
        lab.MODE='page-change'; self.assertNotEqual(hashlib.sha256(html_body()).digest(),original)
    def test_restore_original_snapshot(self):
        lab.MODE='approved'; original=html_body()
        lab.MODE='page-change'; self.assertNotEqual(html_body(),original)
        lab.MODE='approved'; self.assertEqual(html_body(),original)
    def test_policy_does_not_allow_inline(self): self.assertNotIn("'unsafe-inline'", POLICY)

class TestDeliveredFixture(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=ThreadingHTTPServer(('127.0.0.1',0), lab.Handler)
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True); cls.thread.start()
        cls.base=f'http://127.0.0.1:{cls.server.server_port}'
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close(); cls.thread.join()
    def tearDown(self): lab.MODE='approved'
    def get(self,mode,path='/'):
        lab.MODE=mode
        with urllib.request.urlopen(self.base+path,timeout=3) as response:
            return response.headers, response.read()
    def test_enforcing_header(self):
        h,b=self.get('approved'); self.assertEqual(h.get('Content-Security-Policy'),POLICY); self.assertIsNone(h.get('Content-Security-Policy-Report-Only'))
    def test_report_only_header(self):
        h,b=self.get('report-only'); self.assertEqual(h.get('Content-Security-Policy-Report-Only'),POLICY); self.assertIsNone(h.get('Content-Security-Policy'))
        self.assertIn(b'dataset.inline',b)
    def test_missing_header_detected(self):
        h,_=self.get('header-change'); self.assertIsNone(h.get('Content-Security-Policy')); self.assertIsNone(h.get('Content-Security-Policy-Report-Only'))
    def test_changed_delivered_resource(self):
        _,a=self.get('approved','/checkout-v1.js'); _,b=self.get('script-change','/checkout-v1.js')
        self.assertEqual(digest(a),DIGEST); self.assertNotEqual(digest(b),DIGEST)
    def test_delivered_body_changes_and_restores(self):
        _,a=self.get('approved'); _,b=self.get('page-change'); _,c=self.get('approved')
        self.assertNotEqual(hashlib.sha256(a).digest(),hashlib.sha256(b).digest()); self.assertEqual(a,c)

if __name__=='__main__': unittest.main(verbosity=2)
