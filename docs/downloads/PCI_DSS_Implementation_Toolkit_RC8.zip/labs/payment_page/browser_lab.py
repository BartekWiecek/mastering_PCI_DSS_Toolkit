"""Synthetic local laboratory. No account data, no external services."""
import base64, hashlib, json, threading, sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from playwright.sync_api import sync_playwright

APPROVED = b'document.body.dataset.approved = "yes";\n'
CHANGED = b'document.body.dataset.approved = "changed";\n'
DIGEST = 'sha384-' + base64.b64encode(hashlib.sha384(APPROVED).digest()).decode('ascii')
POLICY = "default-src 'none'; script-src 'self'; base-uri 'none'; form-action 'none'"
MODE = 'approved'

def html_body():
    extra = '<p>Unexpected fixture change</p>' if MODE == 'page-change' else ''
    return (f'<!doctype html><html lang="en"><head><meta charset="utf-8">'
            f'<title>Local checkout fixture</title></head><body>'
            f'<h1>Demo only: no card data</h1>{extra}'
            f'<script src="/checkout-v1.js" integrity="{DIGEST}"></script>'
            '<script>document.body.dataset.inline = "ran";</script></body></html>').encode()

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/checkout-v1.js':
            data = CHANGED if MODE == 'script-change' else APPROVED
            self.send_response(200); self.send_header('Content-Type','application/javascript')
        elif self.path == '/':
            data = html_body(); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8')
            if MODE == 'report-only':
                self.send_header('Content-Security-Policy-Report-Only', POLICY)
            elif MODE != 'header-change':
                self.send_header('Content-Security-Policy', POLICY)
        else:
            self.send_error(404); return
        self.send_header('Cache-Control','no-store'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def log_message(self,*args): pass

def snapshot(page,url):
    page.add_init_script("""window.fixtureViolations = [];
        document.addEventListener('securitypolicyviolation', e => {
          window.fixtureViolations.push({disposition: e.disposition,
             directive: e.effectiveDirective, blocked: e.blockedURI});
        });""")
    response=page.goto(url,wait_until='load'); assert response.status==200
    return {'csp':response.header_value('content-security-policy'),
            'csp_report_only':response.header_value('content-security-policy-report-only'),
            'body_sha256':hashlib.sha256(response.body()).hexdigest(),
            'approved':page.locator('body').get_attribute('data-approved'),
            'inline':page.locator('body').get_attribute('data-inline')}

def run():
    global MODE
    server=ThreadingHTTPServer(('127.0.0.1',0), Handler)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    url=f'http://127.0.0.1:{server.server_port}/'; results=[]
    try:
        with sync_playwright() as p:
            exe='/usr/bin/chromium' if Path('/usr/bin/chromium').exists() else None
            browser=p.chromium.launch(executable_path=exe, headless=True)
            # Each test gets a fresh context to avoid using cached content.
            def observe(mode):
                global MODE
                MODE=mode
                ctx=browser.new_context();page=ctx.new_page();out=snapshot(page,url);ctx.close();return out
            baseline=observe('approved')
            assert baseline['approved']=='yes' and baseline['inline'] is None
            results.append({'test':'LAB09-01','observed':'Approved resource executes; CSP blocks inline code','pass':True})
            tampered=observe('script-change')
            assert tampered['approved'] is None and tampered['inline'] is None
            results.append({'test':'LAB09-02','observed':'Changed resource does not execute with original SRI value','pass':True})
            header=observe('header-change')
            assert header['csp']!=baseline['csp'] and header['inline']=='ran'
            results.append({'test':'LAB09-03','observed':'Missing CSP changes header snapshot; harmless inline script executes','pass':True})
            body=observe('page-change');assert body['body_sha256']!=baseline['body_sha256']
            results.append({'test':'LAB09-04','observed':'Delivered HTML change alters recorded body hash','pass':True})
            restored=observe('approved');assert restored==baseline
            results.append({'test':'LAB09-05','observed':'Restored header and HTML match baseline; approved script executes','pass':True})
            # Report-only is tested independently; a violation event may be dispatched asynchronously.
            MODE='report-only'; ctx=browser.new_context(); page=ctx.new_page(); ro=snapshot(page,url)
            assert ro['csp'] is None and ro['csp_report_only']==POLICY
            assert ro['approved']=='yes' and ro['inline']=='ran'
            page.wait_for_function("window.fixtureViolations.some(v => v.disposition === 'report' && v.directive.startsWith('script-src'))", timeout=5000)
            violations=page.evaluate('window.fixtureViolations'); ctx.close()
            results.append({'test':'LAB09-06','observed':'Report-only did not block inline code; violation event observed','violations':violations,'pass':True})
            report={'fixture':'local synthetic checkout','browser':browser.version,'integrity':DIGEST,'policy':POLICY,'results':results,'limitations':'Local synthetic test only. No dynamic dependency coverage, continuous monitoring, real personnel alerting, provider integration or PCI DSS validation.'}
            browser.close()
        print(json.dumps(report,indent=2)); return report
    finally:
        server.shutdown(); server.server_close(); thread.join()

if __name__=='__main__':run()
