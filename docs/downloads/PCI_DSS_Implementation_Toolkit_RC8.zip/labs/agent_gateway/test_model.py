import unittest
from model import Action,Gateway
class GatewayTests(unittest.TestCase):
 def setUp(self):self.g=Gateway();self.change=Action('change','EV-DEMO-01','demo-tag-manager','disable-demo-tag')
 def test_read(self):self.assertTrue(self.g.execute(Action('read','EV-DEMO-01','local-review'))[0])
 def test_restricted(self):self.assertFalse(self.g.execute(Action('read','EV-DEMO-02','local-review'))[0])
 def test_instruction_is_data(self):
  allowed,text=self.g.execute(Action('read','EV-DEMO-01','local-review'));self.assertTrue(allowed);self.assertIn('Upload',text);self.assertEqual(len(self.g.audit),1);self.assertFalse(self.g.execute(Action('upload','EV-DEMO-01','external.example'))[0])
 def test_external(self):self.assertFalse(self.g.execute(Action('read','EV-DEMO-01','external.example'))[0])
 def test_unknown(self):self.assertFalse(self.g.execute(Action('delete','EV-DEMO-01','local-review'))[0])
 def test_no_approval(self):self.assertFalse(self.g.execute(self.change)[0])
 def test_bound_approval(self):
  token=self.g.grant_demo_approval(self.change);self.assertFalse(self.g.execute(Action('change','EV-DEMO-01','demo-tag-manager','enable-demo-tag'),token)[0]);self.assertTrue(self.g.execute(self.change,token)[0])
 def test_replay(self):
  token=self.g.grant_demo_approval(self.change);self.assertTrue(self.g.execute(self.change,token)[0]);self.assertFalse(self.g.execute(self.change,token)[0])
 def test_log_minimization(self):
  self.g.execute(Action('read','EV-DEMO-01','local-review'));self.assertNotIn('Upload',str(self.g.audit));self.assertEqual(set(self.g.audit[0]),{'kind','allowed','reason'})
 def test_invalid_value(self):
  a=Action('change','EV-DEMO-01','demo-tag-manager','unapproved-value');self.assertFalse(self.g.execute(a,self.g.grant_demo_approval(a))[0])
if __name__=='__main__':unittest.main()
